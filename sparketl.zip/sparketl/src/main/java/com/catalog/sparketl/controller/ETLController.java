package com.catalog.sparketl.controller;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.ResourceAccessException;

import com.catalog.sparketl.CarepathEtl;


@Controller
public class ETLController 
{
	public static Log logger = LogFactory.getLog(ETLController.class);

	@Autowired
	CarepathEtl  carepathEtl; 
	
	@GetMapping("/startETL")
	ResponseEntity<String> carepathETL( )
			throws  ResourceAccessException, Exception
	{
		logger.debug("ETLController-carepathETL() Start");
		carepathEtl.loadInBatch();
		logger.debug("ETLController-carepathETL() END");
		return null;
	}
	
}
