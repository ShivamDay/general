package com.catalog.sparketl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequestBuilder;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class CarepathEtl {

	public static Log logger = LogFactory.getLog(SparketlApplication.class);
	
	@Value("${carepath.etl.es.index}")
	private String index;
	
	@Value("${carepath.etl.es.index.type}")
	private  String type;
	
	@Value("${carepath.etl.es.index.mapping}")
	private String mapping;
	
	
	public Client client() {
        TransportClient client = null;
        try {
           /* final Settings elasticsearchSettings = Settings.builder()
              .put("client.transport.sniff", true)
              .put("path.home", elasticsearchHome)
              .put("cluster.name", clusterName).build();*/
            
            client = new PreBuiltTransportClient(Settings.EMPTY);
            client.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("10.37.195.77"), 9300));
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return client;
    }
	
	public String createIndex()
	{
		logger.debug("CarepathEtl-createIndex Start ");
		
		CreateIndexRequestBuilder create = client().admin().indices().prepareCreate(index);
		//create.setSettings("");
		//create.addMapping("5c011f04dbc6f023d434ad7a.activity", "{      \"properties\": { \"updt_dt\": {          \"type\": \"date\",          \"format\": \"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd||yyyy-MM-dd HH:mm:ss\"        },		\"insrt_dt\": {          \"type\": \"date\",          \"format\": \"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd||yyyy-MM-dd HH:mm:ss\"        },		\"last_mdifd_dt\": {          \"type\": \"date\",          \"format\": \"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd||yyyy-MM-dd HH:mm:ss\"        },		\"crtd_dt\": {          \"type\": \"date\",          \"format\": \"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd||yyyy-MM-dd HH:mm:ss\"        },		\"sys_modstm\": {          \"type\": \"date\",          \"format\": \"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd||yyyy-MM-dd HH:mm:ss\"        },		\"dt\": {          \"type\": \"date\",          \"format\": \"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd||yyyy-MM-dd HH:mm:ss\"        },		\"last_refnc_dt\": {          \"type\": \"date\",          \"format\": \"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd||yyyy-MM-dd HH:mm:ss\"        },		\"last_vwd_dt\": {          \"type\": \"date\",          \"format\": \"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd||yyyy-MM-dd HH:mm:ss\"        }      }    } ");
		create.addMapping(type, "{\"properties\":{\"Duration\":{\"type\":\"long\"},\"_posted_date\":{\"type\":\"long\"},\"activity_name\":{\"type\":\"keyword\",\"ignore_above\":256},\"beneift result key\":{\"type\":\"keyword\",\"ignore_above\":256},\"case account key\":{\"type\":\"keyword\",\"ignore_above\":256},\"case account name\":{\"type\":\"keyword\",\"ignore_above\":256},\"case address line 1\":{\"type\":\"keyword\",\"ignore_above\":256},\"case address line 2\":{\"type\":\"keyword\",\"ignore_above\":256},\"case ae confirmation\":{\"type\":\"keyword\",\"ignore_above\":256},\"case ae record\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case agent assistence needed\":{\"type\":\"keyword\",\"ignore_above\":256},\"case assigned group\":{\"type\":\"keyword\",\"ignore_above\":256},\"case assistance request\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case assistance request reason  ind\":{\"type\":\"keyword\",\"ignore_above\":256},\"case authorized baa signatory email\":{\"type\":\"keyword\",\"ignore_above\":256},\"case bi completed time dt\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case blizzard eligible flag\":{\"type\":\"keyword\",\"ignore_above\":256},\"case business hours\":{\"type\":\"keyword\",\"ignore_above\":256},\"case business key\":{\"type\":\"keyword\",\"ignore_above\":256},\"case call mentioning\":{\"type\":\"keyword\",\"ignore_above\":256},\"case call source\":{\"type\":\"keyword\",\"ignore_above\":256},\"case caller email\":{\"type\":\"keyword\",\"ignore_above\":256},\"case caller phone number\":{\"type\":\"keyword\",\"ignore_above\":256},\"case caller type code\":{\"type\":\"keyword\",\"ignore_above\":256},\"case case age\":{\"type\":\"keyword\",\"ignore_above\":256},\"case case reason\":{\"type\":\"keyword\",\"ignore_above\":256},\"case close date\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case closed by\":{\"type\":\"keyword\",\"ignore_above\":256},\"case comment\":{\"type\":\"keyword\",\"ignore_above\":256},\"case contact id\":{\"type\":\"keyword\",\"ignore_above\":256},\"case coordinated medical insurance  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case coordinated pharmacy insurance  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case create date\":{\"type\":\"keyword\",\"ignore_above\":256},\"case created by\":{\"type\":\"keyword\",\"ignore_above\":256},\"case description\":{\"type\":\"keyword\",\"ignore_above\":256},\"case duration\":{\"type\":\"keyword\",\"ignore_above\":256},\"case enrollment date\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case entitlement name\":{\"type\":\"keyword\",\"ignore_above\":256},\"case event create dt\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case event sub status cd\":{\"type\":\"keyword\",\"ignore_above\":256},\"case form completion support txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case form txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case govt\":{\"properties\":{\" exl override ind\":{\"type\":\"keyword\",\"ignore_above\":256}}},\"case govt exl override ind\":{\"type\":\"keyword\",\"ignore_above\":256},\"case impact txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case inbound fax line  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case inbound fax line type  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case is active\":{\"type\":\"keyword\",\"ignore_above\":256},\"case issue details  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case janssen link enroll from bi delay txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case key\":{\"type\":\"keyword\",\"ignore_above\":256},\"case last case status\":{\"type\":\"keyword\",\"ignore_above\":256},\"case last modified by\":{\"type\":\"keyword\",\"ignore_above\":256},\"case last update\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case last updated date\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case link enroll from bi delay ind\":{\"type\":\"keyword\",\"ignore_above\":256},\"case location\":{\"type\":\"keyword\",\"ignore_above\":256},\"case manual bi reasoning txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case medical insurance coordination notes  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case milestone status\":{\"type\":\"keyword\",\"ignore_above\":256},\"case missing info\":{\"type\":\"keyword\",\"ignore_above\":256},\"case missing info end\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case missing info start\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case missing info time\":{\"type\":\"keyword\",\"ignore_above\":256},\"case new fax received  ind\":{\"type\":\"keyword\",\"ignore_above\":256},\"case number mk\":{\"type\":\"keyword\",\"ignore_above\":256},\"case open date\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case origin\":{\"type\":\"keyword\",\"ignore_above\":256},\"case outcome cd\":{\"type\":\"keyword\",\"ignore_above\":256},\"case outcome code\":{\"type\":\"keyword\",\"ignore_above\":256},\"case owner id\":{\"type\":\"keyword\",\"ignore_above\":256},\"case pa initiated  ind\":{\"type\":\"keyword\",\"ignore_above\":256},\"case pa submission type txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case parent key\":{\"type\":\"keyword\",\"ignore_above\":256},\"case pef received date\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case pef received time\":{\"type\":\"keyword\",\"ignore_above\":256},\"case pharmacy insurance coordination notes  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case pharmacy receipt dt\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case pk\":{\"type\":\"integer\"},\"case prescriber jnj id\":{\"type\":\"keyword\",\"ignore_above\":256},\"case priority\":{\"type\":\"keyword\",\"ignore_above\":256},\"case program id txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case provider registered on portal\":{\"type\":\"keyword\",\"ignore_above\":256},\"case pt mk\":{\"type\":\"keyword\",\"ignore_above\":256},\"case recommended action\":{\"type\":\"keyword\",\"ignore_above\":256},\"case record type code\":{\"type\":\"keyword\",\"ignore_above\":256},\"case related campaign  name\":{\"type\":\"keyword\",\"ignore_above\":256},\"case reopened  ind\":{\"type\":\"keyword\",\"ignore_above\":256},\"case rx included  ind\":{\"type\":\"keyword\",\"ignore_above\":256},\"case rx num\":{\"type\":\"keyword\",\"ignore_above\":256},\"case salesforce created by\":{\"type\":\"keyword\",\"ignore_above\":256},\"case savings card mk\":{\"type\":\"keyword\",\"ignore_above\":256},\"case selected benefity type\":{\"type\":\"keyword\",\"ignore_above\":256},\"case selected pharmacy insurance  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case site name  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case sla end date\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case sla start date\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"case source code\":{\"type\":\"keyword\",\"ignore_above\":256},\"case status code\":{\"type\":\"keyword\",\"ignore_above\":256},\"case status reason code\":{\"type\":\"keyword\",\"ignore_above\":256},\"case sub type code\":{\"type\":\"keyword\",\"ignore_above\":256},\"case subject\":{\"type\":\"keyword\",\"ignore_above\":256},\"case tc\":{\"type\":\"keyword\",\"ignore_above\":256},\"case today day of week  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case type\":{\"type\":\"keyword\",\"ignore_above\":256},\"case unable to convert detail  txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"case unauthorized baa signatory\":{\"type\":\"keyword\",\"ignore_above\":256},\"case urgency\":{\"type\":\"keyword\",\"ignore_above\":256},\"case valid from\":{\"type\":\"keyword\",\"ignore_above\":256},\"case valid to\":{\"type\":\"keyword\",\"ignore_above\":256},\"case vob delivery day of week\":{\"type\":\"keyword\",\"ignore_above\":256},\"case vob more than 6 months old  ind\":{\"type\":\"keyword\",\"ignore_above\":256},\"company cd\":{\"type\":\"keyword\",\"ignore_above\":256},\"company sid\":{\"type\":\"long\"},\"date key\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"dd_active_cases\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_bi_case_origin\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_bi_missing_info\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_bif_pef_volume\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_cases_on_hold\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_closed_cases\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_duration\":{\"type\":\"integer\"},\"dd_new_bi_cases\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_patient_age\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_patients\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_prescribers\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_reccurring_bi_cases\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_sites\":{\"type\":\"keyword\",\"ignore_above\":256},\"district name\":{\"type\":\"keyword\",\"ignore_above\":256},\"district rdt no\":{\"type\":\"keyword\",\"ignore_above\":256},\"district sid\":{\"type\":\"long\"},\"faxdate\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"franchise cd\":{\"type\":\"keyword\",\"ignore_above\":256},\"franchise sid\":{\"type\":\"long\"},\"is_26week\":{\"type\":\"integer\"},\"is_patient_notnull\":{\"type\":\"integer\"},\"is_target\":{\"type\":\"keyword\",\"ignore_above\":256},\"jcar rep\":{\"type\":\"keyword\",\"ignore_above\":256},\"jv ref id\":{\"type\":\"keyword\",\"ignore_above\":256},\"med name\":{\"type\":\"keyword\",\"ignore_above\":256},\"medication key\":{\"type\":\"keyword\",\"ignore_above\":256},\"medication tc\":{\"type\":\"keyword\",\"ignore_above\":256},\"net turnaround time\":{\"type\":\"float\"},\"new/recurring bi\":{\"type\":\"keyword\",\"ignore_above\":256},\"office staff key\":{\"type\":\"keyword\",\"ignore_above\":256},\"patient key\":{\"type\":\"keyword\",\"ignore_above\":256},\"prescriber key\":{\"type\":\"keyword\",\"ignore_above\":256},\"pt dob\":{\"type\":\"keyword\",\"ignore_above\":256},\"region name\":{\"type\":\"keyword\",\"ignore_above\":256},\"region rdt no\":{\"type\":\"keyword\",\"ignore_above\":256},\"region sid\":{\"type\":\"long\"},\"selling division cd\":{\"type\":\"keyword\",\"ignore_above\":256},\"selling division sid\":{\"type\":\"long\"},\"ship date\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"site key\":{\"type\":\"keyword\",\"ignore_above\":256},\"source\":{\"type\":\"keyword\",\"ignore_above\":256},\"source description\":{\"type\":\"keyword\",\"ignore_above\":256},\"territory name\":{\"type\":\"keyword\",\"ignore_above\":256},\"territory rdt no\":{\"type\":\"keyword\",\"ignore_above\":256},\"territory sid\":{\"type\":\"long\"},\"time to triage\":{\"type\":\"long\"},\"time_to_shipment\":{\"type\":\"long\"},\"treatment location\":{\"type\":\"keyword\",\"ignore_above\":256},\"week_end_dt\":{\"type\":\"date\",\"format\":\"strict_date_hour_minute_second||yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis||yyyy-MM-dd\"},\"bi results plan type txt\":{\"type\":\"keyword\",\"ignore_above\":256},\"bi results insurance type\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_case_missing_info\":{\"type\":\"keyword\",\"ignore_above\":256},\"dd_beneift_result_key\":{\"type\":\"keyword\",\"ignore_above\":256}}}");
		//create.addMapping(type, mapping);
		CreateIndexResponse actionGet = create.execute().actionGet();
		
		logger.debug("CarepathEtl-createIndex END ");
		return "";
	
	}
	
	public void loadInBatch()
	{
		//createIndex();
		logger.debug("Carepath Spark ETL started ");
		System.out.println("--------------------------------------------- Carepath Spark ETL STARTS -------------------------------------------------------");		
		Map<String, Integer> caseIdMap = getMinMaxId();
		Integer minId = caseIdMap.get("min_id");
		Integer nextCount = minId;
		Integer maxId = caseIdMap.get("max_id");
		Integer rowCount = maxId / 240;
		SparkSession spark = SparkSession.builder().appName("sampleRecords").master("local[*]")
				.getOrCreate();
		
		while(nextCount < maxId)
		{
			nextCount = nextCount + rowCount; 
			logger.debug("Processing IDS from "+ minId + " -- to -- " + nextCount);
			String idsql = "(SELECT *, extract(epoch from sysdate) as _posted_date, 'carepath' as activity_name from pas.vw_carepath_ask_table where \"case pk\" between " 
					+ minId + " and " + nextCount + " ) as tmp";
			System.out.println("-------------------------------------------------------------------------------------------------------------");
			System.out.println("Processing SQL ----> " + idsql);
			spark.conf().set("spark.network.timeout", "600s");
			Dataset<Row> data = spark.read().format("jdbc")
					.option("url", "jdbc:redshift://cdedev.cwncayiqp41u.us-east-1.redshift.amazonaws.com:5439/cdepoc")
					.option("user", "jcp_dev_ds")
					.option("password", "H#LUIu7HZyuz")
				    .option("dbtable", idsql)
				    .load();
				//load.printSchema();
			//uniqueIdload.show();
			String indexTypeStr = index + "/" + type;
			data.write()
			  .format("org.elasticsearch.spark.sql")
			  .option("es.nodes.wan.only","true")
			  .option("es.port","9200")
			  //.option("es.nodes", "localhost")
			  .option("es.nodes", "AWSACMNVA3077")
			  .option("es.http.timeout", "60s")
			  .mode(SaveMode.Append)
			  .save(indexTypeStr);
			System.out.println("Ids processed from "+ minId + " to " + nextCount);
			System.out.println("-----------------------------------------------------------------------------------------------------------------------------------");
			minId = nextCount + 1;
		}
			System.out.println("Spark ETL end");
			logger.debug("-------------------- Carepath Spark ETL Ends -------------------- ");
	}	
	
	public static  Map<String, Integer> getMinMaxId()
	{
		Connection conn = null;
        Statement stmt = null;
        Map<String, Integer> caseIdMap = new java.util.HashMap<String, Integer>();
        try
        {
           //Dynamically load driver at runtime.
           //Redshift JDBC 4.1 driver: com.amazon.redshift.jdbc41.Driver
           //Redshift JDBC 4 driver: com.amazon.redshift.jdbc4.Driver
           Class.forName("com.amazon.redshift.jdbc.Driver");

           //Open a connection and define properties.
           System.out.println("Connecting to database...");
           Properties props = new Properties();

           //Uncomment the following line if using a keystore.
           //props.setProperty("ssl", "true");
           
           props.setProperty("user", "jcp_dev_ds");
           props.setProperty("password", "H#LUIu7HZyuz");
           conn = DriverManager.getConnection("jdbc:redshift://cdedev.cwncayiqp41u.us-east-1.redshift.amazonaws.com:5439/cdepoc", props);

           stmt = conn.createStatement();
           String sql;
           sql = "select min(\"case pk\") as min_case, max(\"case pk\") as max_case from pas.vw_carepath_ask_table;";
           ResultSet rs = stmt.executeQuery(sql);

           //Get the data from the result set.
           while(rs.next())
           {
              //Retrieve two columns.
              Integer minCaseId = rs.getInt("min_case");
              Integer mixCaseId = rs.getInt("max_case");

              //Display values.
              caseIdMap.put("min_id", minCaseId);
              caseIdMap.put("max_id", mixCaseId);
           }
           rs.close();
           stmt.close();
           conn.close();
        }catch(Exception ex){
           //For convenience, handle all errors here.
           ex.printStackTrace();
        }finally{
           //Finally block to close resources.
           try{
              if(stmt!=null)
                 stmt.close();
           }catch(Exception ex){
           }// nothing we can do
           try{
              if(conn!=null)
                 conn.close();
           }catch(Exception ex){
              ex.printStackTrace();
           }
        }
        System.out.println("Finished connectivity test.");
        return caseIdMap;
     }
	
}

